#set document(title: "A Consistent Cell Model Does Not Establish Spectral Acquisition Superiority", author: "Spectral Ambiguity research workspace", date: datetime(year: 2025, month: 8, day: 7))
#set page(paper: "a4", margin: (x: 22mm,y: 20mm), footer: context align(center,text(size:8pt,fill:gray)[Spectral Ambiguity · Phase 2 · #counter(page).display()]))
#set text(font:"Libertinus Serif",size:10.5pt)
#set par(justify:true,leading:.65em)
#set heading(numbering:"1.")
#show heading.where(level:1):set text(size:13.5pt)
#set math.equation(numbering:"(1)")
#show figure.caption:set text(size:8.5pt)
#let s=json("data/summary.json")

#align(center)[
  #set par(justify:false)
  #text(size:19pt,weight:"bold")[A Consistent Cell Model Does Not Establish Spectral Acquisition Superiority]
  #v(2mm)
  A corrective experiment, a clipping identity, and a physical resource audit \
  7 August 2025 · Unreviewed computational research report
]
#v(2mm)

*Abstract.* A previous positive-spectral experiment-design pilot accelerated finite-menu selection but failed its scientific acquisition criterion. It also chose observations with a midpoint-grid surrogate while reporting tighter endpoint-cell intervals. We remove that mismatch: the new selector and inference use the same raw endpoint-cell model. Ordered endpoint uncertainty gives a useful convex-geometric identity: a shared joint-pair hull clipped by two nonoverlapping excluded caps can be optimized through the minimum of two single-cut problems. An independent implementation review covers 80 seeded problems, 20 convex-weight comparisons and numerical regressions; the combined package passes 26 tests. Nevertheless, all five policies miss the unchanged uncertainty target on all nine new physical cases. A post-outcome resolution diagnostic shows why this is not a useful ranking experiment: coarse-cell ambiguity remains above the target even with every available observation in #s.coarse_all_data_impossibility_certificates cases, while refinement gives widths below the target in #s.fine_all_data_width_under_target cases. A separate source/code audit does not establish the assumed independent per-time QMC costs. We retain the verified implementation and explicit negative evidence, reject the present acquisition claim as the principal moonshot, and make no breakthrough, novelty-priority or publication-readiness claim.

= What changed, and what did not

The original 29 April report and result bundle are preserved. Their 5.16× median finite-menu timing speedup is historical evidence for that implementation and benchmark, not a measurement of this new selector. Their negative acquisition result is not reclassified.

Phase 2 was preregistered before its implementation. The scientific gate remained at least twofold less acquisition cost at the same interval width than the strongest feasible nonoracle comparator in at least two of three regimes. The target width stayed 0.10. No result below changes that criterion. Equal independent observation costs remain an explicitly idealized simulator assumption.

New held-out tests use eight-site spin chains, physical seeds 101, 211 and 307 in each of the existing nonintegrable, near-integrable and gapped coupling regimes. The Gaussian target cutoff is fixed at 0.75J in physical units rather than growing with a support bound. Frequency coordinates alone are normalized by a coupling-derived spectral bound. The initial two observations are followed by at most eight new choices from 42 times. Errors are independent uniform values in ±0.003. Every policy receives the same hidden observation table and support knowledge, and no physical peak locations.

= A consistent endpoint model

Let $F$ contain nonnegative frequency-cell masses summing to one and compatible with existing raw endpoint inequalities. Candidate prediction for $x in F$ lies in
$ I_j(x)=[k_j^- dot x-epsilon_j, k_j^+ dot x+epsilon_j]. $
The target interval is the minimum of $c^- dot x$ to the maximum of $c^+ dot x$ over $F$. Two mass vectors $x,y$ can survive a common future observation exactly when
$ u=k_j^- dot x-k_j^+ dot y<=t, quad v=k_j^- dot y-k_j^+ dot x<=t, quad t=2epsilon_j. $
Therefore the maximum of $h=c^+ dot x-c^- dot y$ under those cuts is the exact worst child *of this outer cell model*. It is not automatically the exact physical infinite-dimensional problem: independent envelopes discard relationships between kernels inside a cell. For example, one cell and identical measurement/target kernels can retain a target range even when the actual measured target is known exactly.

== Ordered clipping caps

For every nonnegative pair,
$ u+v=(k_j^--k_j^+) dot (x+y)<=0. $
Let $P$ be the full convex projected pair set, or the convex hull of cached feasible joint pairs. It obeys the same inequality. For $t>=0$, define single-cut maxima $A=max_(P,u<=t)h$ and $B=max_(P,v<=t)h$. Then
$ max_(P,u<=t,v<=t)h = min(A,B). $
*Proof.* The left side is at most the right. Assume $A<=B$ and take corresponding maximizers $p,q$. If $p$ obeys both cuts, equality follows. Otherwise $v(p)>t$ implies $u(p)<t$. If $B>A$, a small mixture toward $q$ stays within the first cut and increases height, contradicting optimality of $p$. Hence $A=B$. If $q$ is not already feasible for both cuts, its equal-height segment with $p$ crosses $v=t$ at a point satisfying $u<=-t<=t$. This proves equality, including zero noise.

For a finite cache, each single-cut optimum is attained at a stored vertex or an edge crossing the cut. Enumerating all vertex pairs computes the cached lower bound in $O(M K^2)$ after projection. Generic three-vertex clipping is unnecessary. This argument allows signed sine/cosine kernels as well as Laplace kernels, provided endpoint ordering holds; it does not establish a positive spectral representation for arbitrary cross-operator hardware data.

Exact full-oracle dual upper bounds and cache lower bounds retain the finite-menu stopping rule $U<=min_j L_j+eta$. A cache is local to one fixed $F$. Generic optimal recovery, oracle caching and convex-hull exchange remain established; the elementary specialization is not claimed as a new general optimization principle @braun2019.

== Implementation and independent verification

The endpoint module keeps untransformed endpoint inequalities. Both compared full-oracle modes use persistent HiGHS simplex models. Positive row scaling exposes informative tiny coefficients, while raw primal/dual audits refer to the original finite model. The code rejects stale feasible-region/table identities and externally supplied infeasible cache pairs, validates integral indices, and bounds huge finite errors without overflow. Returned bounds must be finite. Feasible-primal/dual gaps are checked rather than accepting the optimizer's objective alone.

Independent review found and drove fixes for tiny-action scores, stale state, malformed pairs, zero-noise clipping roundoff and huge-error NaNs that could otherwise prevent termination. The final endpoint source hash is recorded in the experiment and review. Its separate test suite covers 80 seeded problems against independently assembled SciPy two-copy LPs, 20 comparisons against convex-weight master LPs, rational dual expressions and the reported regressions. The complete copied package passes 26 tests.

Numerical boundary cases can explicitly reject. Projected lower bounds use extended precision and a guard, not a universal formal interval proof for arbitrary real inputs. Exact rational raw-LP dual evaluations are distinguished from that numerical geometry. The resolution diagnostic audits every raw primal inequality rationally before calling its objective an ambiguity lower certificate. All 18 primal/dual proof objects are retained. A separate checker imports neither the optimizer nor production package; exact rational checks reject false claims and infeasible primals. These checks remain active under optimized Python execution.

= Results and the failed gate

All 45 acquisition runs completed. All five policies reached the target in *0 of 9* cases: coherent-cell minimax; the original inflated-midpoint minimax; robust separation of the current extremal pair; c-optimal design using the correct uniform-noise variance; and the original variance variant. The total of #s.intervals reported intervals contained their hidden numerical physical targets. Correcting the variance model did not establish superiority. Runtime values are retained for reproducibility but are not a new controlled speedup comparison.

After observing universal failure, we performed a labeled diagnostic, not a changed success test. Every one of the same 42 observations was supplied at 129 and 1025 frequency cells, with identical noise bounds, target and hidden data. Feasible primal pairs and corrected duals bracket the optimal ambiguity of each stored finite outer model. At coarse resolution, #s.coarse_all_data_impossibility_certificates of nine ambiguity lower certificates exceed 0.10 even with all observations. Information monotonicity then rules out reaching that target from a subset in those same models. At finer resolution, #s.fine_all_data_width_under_target of nine certified upper widths fall below 0.10.

The coarse-cell result is a limitation of the outer relaxation, not a fundamental lower bound on physical spectral knowledge. It also means the acquisition failure cannot rank the policies fairly. Refinement was not used to replace the preregistered acquisition runs, tune a policy, or declare the unchanged scientific gate passed.

#figure(image("figures/phase2-diagnostic.svg",width:100%),caption:[A: final interval widths after eight additional observations, all failures at the declared budget retained. B: all-data ambiguity at two resolutions. Primal/dual gaps are smaller than the plotted markers; the dashed line is the unchanged target. The corrected-variance c-optimal comparator is shown; the fifth policy and every raw trajectory remain in the JSON data.])

= Physical acquisition costs remain a separate gap

Positive Euclidean responses do not imply independent per-time costs. Andreoli et al. obtain multiple correlated imaginary-time values along stored GFMC propagation @andreoli2022. The inspected SmoQyDQMC measurement loop propagates through time slices and periodically stabilizes Green matrices; individual measurements cost work, but no inspected timing establishes that sparse time selection removes the dominant expense. A trajectory-count/maximum-length allocation with shared covariance would be a different resource problem.

A real-time hardware alternative exists in the response circuits of Kökcü et al. @kokcu2024. However, their free SSH demonstration needs model-specific positivity, a strong single-sinusoid baseline and explicit finite-pulse/readout/coherent-error treatment. Shot uncertainty alone covers device expectations, not an ideal Hamiltonian. Official archive requests returned HTTP403 during independent investigation; raw count bytes were not inspected and no access restriction was bypassed. We make no hardware-replay claim.

A proposed maximal-amplitude product preparation has an exact first-moment construction for quadratic evolution, but fails as a general interacting or arbitrary thermal-state response algorithm. Strong existing finite-amplitude interacting Green-function protocols further restrict novelty @bishop2025. This lead was bounded and not relabeled as a breakthrough.

= Research decision

The consistent formulation closes a mathematical mismatch and the new review closes concrete implementation failures. It does not close physical utility, genuine originality or reproducible scientific superiority. The present independent-time QMC acquisition claim is rejected as the principal moonshot. Preserved outputs include source, tests, the unchanged first-phase results, phase-2 preregistration, every failed acquisition trace, rational diagnostic bounds, mathematical derivations and the physical resource audit.

Future work would need an actual measured resource model and stronger external validation, not more favorable presentation or a relaxed target. No human peer review, manuscript submission or public publication has occurred. Public GitHub creation remains pending the separate explicit approval required by automatic approval review. This report records defensible progress and remaining gaps; it does not certify perfection or completion of the original breakthrough aim.

#bibliography("phase2-references.bib",style:"ieee",title:"References")
