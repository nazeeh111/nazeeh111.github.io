#set document(title: "Projected Witness Reuse for Positive Spectral Experiment Design", author: "Spectral Ambiguity research workspace", date: datetime(year: 2026, month: 10, day: 29))
#set page(paper: "a4", margin: (x: 21mm, y: 19mm), numbering: "1", footer: context align(center, text(size: 8pt, fill: gray)[Spectral Ambiguity · Research report · #counter(page).display()]))
#set text(font: "Libertinus Serif", size: 10.5pt)
#set par(justify: true, leading: .65em)
#set heading(numbering: "1.")
#show heading.where(level: 1): set text(size: 14pt)
#show heading.where(level: 2): set text(size: 11.5pt)
#set math.equation(numbering: "(1)")
#set figure(gap: 5pt)
#show figure.caption: set text(size: 8.5pt)
#let stats = json("../results/summary.json")

#align(center)[
  #set par(justify: false)
  #text(size: 20pt, weight: "bold", hyphenate: false)[Projected Witness Reuse for Positive Spectral Experiment Design]
  #v(3mm)
  #text(size: 12pt)[A computational acceleration study and a negative acquisition result]
  #v(2mm)
  Open computational research report · 29 October 2026 \
  #text(size: 9pt)[Prepared with Codex; automated independent review, not human peer review]
]
#v(3mm)

*Abstract.* We study the computational cost of selecting a noisy Euclidean correlator measurement under a positive-spectral minimax criterion. The criterion itself is established optimal-recovery mathematics. Our implementation reuses adversarial spectrum differences across candidate measurements: a shared inner hull yields simultaneous lower bounds through two-dimensional strip clipping, while residual-corrected LP duals bound evaluated candidates from above. In exact arithmetic, the resulting elimination rule certifies a finite-menu choice and needs at most one full oracle call per candidate. Across 18 held-out finite-grid spin-response cases, three timed trials per case gave a #stats.selection.hull_speedup_median× median speedup over warm-started exhaustive HiGHS selection, with a #stats.selection.hull_speedup_min–#stats.selection.hull_speedup_max× range and matching objectives within 10⁻⁷. A simpler ray cache captures much of the benefit. Separately, continuous-support inference with outward kernel enclosures and rational dual auditing contained all 412 tested physical target values. However, minimax acquisition reached the declared uncertainty target in only 4 of 9 physical instances, versus 6 for conventional target-specific linear design. The scientific acquisition criterion therefore failed. We report a useful specialized implementation and its limitations, not a new general optimization principle, established scientific superiority, or a publication-ready breakthrough.

= Scientific question and prior work

A positive spectral measure of a quantum observable relates imaginary-time measurements to response quantities that are otherwise difficult to access. At zero temperature, a normalized connected observable gives
$ C(tau) = integral_0^Omega exp(-tau omega) dif mu(omega), quad mu >= 0, quad integral dif mu = 1. $
Our target is a smooth low-frequency weight,
$ T = integral_0^Omega exp(-omega^2 / (2 omega_c^2)) dif mu(omega). $
It is an integrated response quantity, not a pointwise spectral peak, DC transport coefficient, thermodynamic phase diagnosis, or quantum computational advantage. Choosing additional Euclidean times could improve its determination, but inference and acquisition design are different problems.

Lawrence already obtains positive-spectral bounds on linear observables by convex duality @lawrence2024. Abbott and collaborators extend this framework to matrix-valued measures, correlated compatibility regions and finite semidefinite formulations @abbott2026. We do not claim their inference mechanism as new and do not reproduce their full SDP implementations. Slepian kernel sampling supplies a distinct deterministic compression strategy @ohzeki2026; compression alone is not the target-specific acquisition problem considered here.

Expensive-oracle caching is also established. Braun, Pokutta and Zink avoid oracle calls through lazification @braun2017; Bettiol and collaborators build growing oracle-generated convex hulls in robust optimization @bettiol2022. Those precedents sharply limit our originality claim. The research question is whether a particular shared difference-hull geometry makes finite-menu spectral design substantially cheaper, and whether this acquisition rule earns a useful physical advantage. The former can succeed while the latter fails.

The task-local preregistration preceded implementation. It required matching exhaustive scores to absolute 10⁻⁷, at least fivefold fewer pair-oracle calls and twofold lower wall time on most held-out menus of at least 64 actions. A separate scientific gate required at least twofold lower acquisition cost than the strongest feasible nonoracle comparator in at least two of three physical regimes. We retain both criteria after observing the outcomes.

= Established minimax recovery formulation

Let $F$ be a nonempty compact convex set of normalized spectra compatible with existing observations. On a finite grid it is a simplex intersected with linear inequalities. Candidate action $j$ measures $a_j^T x$ with known bounded error $epsilon_j$. Define
$ W_j = max_(x,y in F, |a_j^T (x-y)| <= 2 epsilon_j) c^T (x-y). $ <pair>
This is the largest remaining target disagreement over all possible new observations. To see this, any two spectra in the same noisy observation fiber satisfy the strip condition in @pair. Conversely, a pair satisfying that condition shares the admissible observation at the midpoint of its two predictions. The midpoint of each target interval then has minimax error half its diameter. This derivation identifies the formula as classical optimal recovery rather than an invention.

For a batch of observations $A$ with coordinate error bounds $epsilon_i$, LP duality gives
$ W(A) = min_lambda (2 sum_i epsilon_i |lambda_i| + h_F (c-A^T lambda) + h_F (-c+A^T lambda)), $
where $h_F (v)=max_(x in F) v^T x$. Half this value is the optimal worst-error bound for an affine estimator after centering its residual target range. Our exact best-fixed-batch comparator uses the same pair criterion. A generic claim that positivity or minimax selection is new would therefore be false.

= Projected witness algorithm

== Shared inner approximation

Write $D=F-F$. A solved pair oracle supplies $d_k=x_k-y_k in D$. Convexity and symmetry imply
$ D_K = "conv" {plus.minus d_1, dots, plus.minus d_K} subset.eq D. $
For every candidate, compute
$ L_j = max_(d in D_K, |a_j^T d| <= 2 epsilon_j) c^T d <= W_j. $ <lower>
The map $d mapsto (a_j^T d,c^T d)$ sends the cached hull into a two-dimensional polygon. Intersecting that polygon with a vertical strip and maximizing height computes @lower. An optimum is either a vertex inside the strip or an intersection of a segment with one of its boundaries. The implementation enumerates all crossing segments, including harmless interior ones; it avoids depending on a fragile convex-hull routine.

One LP witness thus contributes to every action. A ray-cache ablation uses only the segment joining each witness to the origin:
$ L_j^"ray" = max_k (c^T d_k) min(1, frac(2 epsilon_j, abs(a_j^T d_k))). $
The zero-denominator convention keeps the unscaled witness. Convex mixing can improve these bounds, but its bookkeeping must justify its own cost.

== Elimination and finite termination

Maintain an upper bound $U$ from an evaluated candidate. Query an unevaluated action with the lowest current $L_j$, insert its maximizing witness and recompute the projected lower bounds. Stop when
$ U <= min_j L_j + eta. $ <stop>
*Proposition.* In exact arithmetic with global pair oracles, @stop returns an action whose objective is at most $eta$ above the best menu objective. No candidate needs more than one full oracle evaluation.

*Proof.* By @lower, $min_j L_j <= min_j W_j$. The incumbent objective is at most $U$, proving the tolerance statement. Once a candidate has been evaluated, its own maximizing witness is feasible for its strip and attains its exact score inside the cached hull. Its lower and upper bounds therefore coincide. Evaluated candidates cannot require another solve. There are at most $M$ candidates. ▢

A cache belongs to one immutable $F$. New measurements shrink $F$; old pairs may then be infeasible and cannot be reused blindly. The public selector resets its cache on every call. Warm LP bases are retained only within a fixed selection problem, separately from witness validity.

== Complexity and a worst-case obstruction

The brute-force comparison solves $M$ two-copy LPs, each with $2N$ nonnegative variables and twice the current data inequalities. If $K$ witnesses suffice, this implementation uses $K$ pair LPs plus two target-extremum LPs. Projections cost $O(M N K)$ over a full rebuild; complete segment clipping costs $O(M K^2)$. Rebuilding after every insertion gives cumulative bounds $O(M N K^2 + M K^3)$, in addition to oracle cost. Stored witnesses require $O(N K)$ memory. Chunked projection temporaries are bounded independently of $M$. These are bounds for this implementation, not an optimal hull data structure.

There is no general sublinear oracle guarantee. For $D="conv"{plus.minus e_1,dots,plus.minus e_M}$, $c=bold(1)$, $a_j=bold(1)-e_j$ and zero error, every true score is one. Before $e_j$ has been obtained, all other cached vertices project onto the line whose strip at zero has height zero. Each missing action can therefore require its own oracle. This geometry can be embedded in normalized positive spectra: use zero-sum vectors $v_i=e_(2i-1)-e_(2i)$ and a sufficiently small translated cross-polytope inside a probability simplex. It is a generic finite-action obstruction, not a claim about every restricted Laplace-time menu.

= Numerical safeguards and continuous support

== Upper bounds are dual bounds

A feasible maximization witness is a lower bound, not an upper certificate. For a minimization LP with $B z<=b$ over one or more unit simplices, any $lambda<=0$ gives
$ q = lambda^T b + sum_("blocks" J) min_(i in J) (f_i-(B^T lambda)_i) <= min f^T z. $ <dual>
The implementation clips multipliers to the required sign and evaluates @dual with an extended-precision numerical guard. An optional exact evaluation treats stored binary64 coefficients and multipliers as rational numbers. This verifies a bound on the stored finite LP without trusting the solver's objective or exact dual feasibility.

Independent review found several consequential failures in early code: large common offsets, tiny supporting inequalities, an incorrect normalization cap for interior first coefficients, and a lost distinction on a restricted simplex face. The final implementation removes irrelevant offsets, scales constraint variation, performs simple supporting-face reduction, repairs witnesses toward a computed interior anchor and audits near-active inequalities with exact rational arithmetic. At almost exact measurement precision it refuses inexact affine transformations that could erase decisive coefficients. It raises an explicit error when the requested numerical selection gap cannot be established. These fixes and reproductions remain in the tests and review record.

The finite selector is still a numerical certificate for a normalized floating model. We do not claim a formally verified certificate for arbitrary unnormalized real inputs, all affine preprocessing, or all solver degeneracies. The exact-arithmetic proposition is separate from that implementation limit.

== Cell enclosures avoid gridding away the physical truth

A point-grid prior can exclude a real spectral peak between grid nodes. For continuous-support checks we instead assign nonnegative mass $m_l$ to each frequency cell $[u_l,v_l]$. Monotonicity gives
$ sum_l exp(-tau v_l)m_l <= C(tau) <= sum_l exp(-tau u_l)m_l. $
If $|C(tau)-y|<=epsilon$, the left expression is at most $y+epsilon$ and the right expression is at least $y-epsilon$. Applying the analogous endpoint bounds to the Gaussian target produces an outer LP relaxation valid for every continuous measure on the declared support.

Kernel endpoints are enclosed using exact rational exponents, 70-digit correctly rounded Decimal exponentials, an outward Decimal step and directed binary conversion. Confidence-bound addition is rounded outward. Rational evaluation of @dual then audits the *raw endpoint LP*, bypassing the selector's rounded affine preprocessing. This certifies the stated continuous measure problem conditional on the support, normalization and bounded-observation assumptions. Floating exact diagonalization supplies numerical physical ground truth; it is not an interval proof of the original many-body Hamiltonian.

= Reproducible experiments

== Physical spectra and blinded observations

The physical generator uses open spin chains with $S^a=sigma^a/2$ and Hamiltonian
$ H = sum_i (S_i^x S_(i+1)^x + S_i^y S_(i+1)^y + Delta S_i^z S_(i+1)^z) + J_2 sum_i S_i^z S_(i+2)^z + sum_i (h_i^x S_i^x + h_i^z S_i^z). $
Three declared coupling regimes are labelled nonintegrable, near-integrable and gapped. These finite-system labels are not thermodynamic conclusions. Independent dense diagonalization constructs the connected local-spin response; its elastic line is removed and weights are normalized by the connected variance. A coupling-based triangle-inequality norm bound, not the observed largest eigenvalue, supplies the upper frequency support. The benchmark design methods receive correlator observations and that support, not exact hidden spectral peaks.

Six-site spectra provide nine held-out physical instances, seeds 11, 23 and 47 in each regime. Separate generator checks include larger systems up to ten sites. Reproducible Kronecker-matrix tests independently check the Hamiltonian, matrix-exponential correlators and Gaussian target rather than merely invoking the same spectral formula twice.

== Selection timing and ablation

The 18 timing problems use 129 grid points with 64 candidate times and 257 points with 128 times, three initial correlators and a fixed bounded error of 0.003. Physical spectra are projected onto the grid *only for this declared finite-model timing experiment*. We run three order-rotated trials per case and report median wall time. Both cached and exhaustive selectors use persistent HiGHS 1.15.1 simplex models with retained bases; the exhaustive method traverses ordered neighboring times. Timings include model construction, target-endpoint LPs, witness checks and clipping. BLAS and OpenMP threads are fixed to one. The final timing run is separate from the acquisition run.

The hull selector achieved a #stats.selection.hull_speedup_median× median speedup (#stats.selection.hull_speedup_min–#stats.selection.hull_speedup_max×); 17 of 18 cases exceeded twofold. Pair-oracle reductions were #stats.selection.pair_call_reduction_min–#stats.selection.pair_call_reduction_max×. The maximum absolute selected-score difference was below 3×10⁻¹³. The computational gate passed on this pilot. Hull mixing was only #stats.selection.hull_vs_ray_median× faster than the simpler ray cache at the median and won 12 of 18 cases. Thus a substantial portion of the gain comes from shared witness reuse, and convex mixing is not indispensable to every measured speedup.

#figure(image("figures/selection.svg", width: 100%), caption: [All 18 held-out finite-model timing cases. A: each point compares the ray and hull cache against the same warm-started exhaustive baseline; the diagonal indicates equal cache performance. Circles denote 64 actions and triangles 128. B: full pair-oracle calls, with exhaustive counts shown for scale. Two target-extremum LPs and all hull overhead are included in timing.])

Fresh-process scaling tests extend to 513 grid points and 256 actions. Peak resident memory ranges from #stats.memory.min_peak_MiB to #stats.memory.max_peak_MiB MiB over all tested methods and sizes, including imports, diagonalization and allocator overhead. Each scaling configuration has one trial; these data establish neither asymptotic complexity empirically nor a memory superiority claim.

#figure(image("figures/scaling.svg", width: 100%), caption: [Illustrative size and memory scaling on fresh processes. Each plotted configuration has one trial. Grid size and menu size grow together. Resident memory includes the entire Python process and physical-model setup.])

== Physical acquisition: predeclared criterion fails

This experiment retains off-grid physical peaks and uses 129 nonuniform frequency cells. Candidate times are shared by all policies. Two initial observations precede at most eight new observations; the target interval width is 0.10. Independent uniform errors lie in the declared ±0.003 interval. This bounded-noise simulator assigns unit observation cost independent of imaginary time; it is not a QMC sampling-cost model or a hardware experiment.

The selector uses a conservatively inflated midpoint-grid design region; every cell measure compatible with the observations remains feasible there. Reported uncertainty comes from the tighter continuous endpoint relaxation. Therefore its chosen minimax score is a conservative surrogate for the final continuous interval objective. This distinction can weaken acquisition, and is not hidden as evidence against exact continuous minimax design.

Comparators include separation of the current target-extremizing pair; conventional Gaussian linear c-optimal gain with a declared identity prior precision and the normalization mode removed; uniform-time, logarithmic-time and seeded random schedules. The linear-design heuristic uses assumed variance $epsilon^2$, whereas the simulated uniform noise has variance $epsilon^2/3$; it is not an oracle matched to the noise distribution. No method sees future observations. All policies share one hidden noise table per physical case. The c-optimal baseline is our explicit linear-design implementation, not a reproduction of every optimized Backus-Gilbert or contemporary spectral method.

#align(center)[#table(columns: (2fr, 1fr), align: (left, center), inset: 5pt,
  table.header([*Policy*], [*Target reached / 9*]),
  [Minimax hull], [4],
  [Current-pair separation], [6],
  [Linear c-optimal], [6],
  [Uniform time], [4],
  [Logarithmic time], [3],
  [Seeded random], [2],
)]

All 412 evaluated physical intervals contained their hidden targets. This is a deterministic containment check under bounded errors, not an empirical estimate of Gaussian confidence coverage. Neither the target-success counts nor the costs meet the preregistered scientific superiority criterion. In particular, successful acquisition cannot be inferred from the computational speedup. Improving a surrogate design score faster does not establish that it buys better physical information.

#figure(image("figures/acquisition.svg", width: 100%), caption: [Negative acquisition result. A: additional observations required to reach continuous interval width 0.10. Grey cells marked 8+ failed within the budget; they are not successful observations at cost eight. B: interval trajectories for the first declared physical test case, nonintegrable seed 11. Two initial observations are excluded from the horizontal count.])

An independent small-menu comparator enumerated every subset of sizes one through three from eight Laplace times, 92 subsets total. Greedy fixed-batch selection matched the exact best subsets at all three sizes. The best worst-case widths were 0.2794403, 0.1449509 and 0.0919121. Rational feasible-pair and dual certificates had maximum gap below 3.1×10⁻¹². This supplies another reason not to claim global adaptive-design superiority.

= Assessment and external-validation pathway

The defensible outcome is a specialized computational accelerator, an exact-arithmetic selection argument, reproducible stress tests and a negative physical-acquisition result. Generic optimal recovery, positive spectral bounds, cached-oracle hulls and dual certificates are established. We have not proved that the exact projected-strip specialization is absent from prior literature. Independent agent reviews are valuable error-finding exercises, not external scientific endorsement.

Before treating this as a publication contribution, a human specialist should review priority against optimal recovery and lazy-oracle methods; another group should reproduce timings on different hardware; the implementation should be tested against alternative hull data structures and further optimized solver reuse. A scientifically stronger follow-up would use actual correlated QMC observations with time-dependent acquisition cost and make the design objective agree with continuous-support inference. That follow-up would be a new preregistered experiment, not a reinterpretation of the failed present criterion.

The repository contains code, exact physical-model checks, all numerical records, the original preregistration, adversarial review, rejected alternatives and reproduction instructions. No manuscript has been submitted, no external researcher has been contacted, and no breakthrough, publication readiness or quantum advantage is claimed.

= Reproduction and provenance

The tested environment is CPython 3.12.15, NumPy 2.3.5, SciPy 1.18.1 and HiGHS 1.15.1 on macOS arm64. Dependency versions are retained in the lock file. Source hashes in the timing data identify the implementation actually measured. The independent final review repeated 100 randomized raw two-copy-LP comparisons, with no objective or bound failures in the supported numerical domain, and documents explicitly rejected near-exact transformations. Standard-library unit tests add independent polygon LPs, off-grid containment, physical matrix functions and all reported numerical regression cases.

All figures are generated from saved JSON results with Matplotlib. This PDF and its editable Typst source are retained together. The report was generated with Codex and checked by separate agent contexts; scientific accountability and future publication decisions require human review.

#bibliography("references.bib", title: "References", style: "ieee")
